<template>
  <NuxtLayout :name="layout" />
</template>

<script lang="ts">
export default {
  data() {
    return {
      layout: 'reset-password',
    };
  },
}
</script>

<style lang="scss">
</style>