<template>
  <NuxtLayout :name="layout" />
</template>

<script lang="ts">
export default {
  data() {
    return {
      layout: 'authorization',
    };
  },
}
</script>

<style lang="scss">
</style>