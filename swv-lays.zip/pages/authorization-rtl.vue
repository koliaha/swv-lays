<template>
  <NuxtLayout :name="layout" />
</template>

<script lang="ts">
export default {
  data() {
    return {
      layout: 'authorization-rtl',
    };
  },
}
</script>

<style lang="scss">
</style>