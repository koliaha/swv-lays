<template>
    <header>Reset Password RTL</header>
    <main>
      layout
    </main>
</template>

<script lang="ts">
</script>

<style lang="scss">
</style>
