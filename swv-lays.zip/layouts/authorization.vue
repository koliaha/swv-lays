<template>
    <header>Authorization</header>
    <main>
      <forms-auth-credentials-form is-rtl="false" />
    </main>
</template>

<script lang="ts">
</script>

<style lang="scss">
</style>
