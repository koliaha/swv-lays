<template>
    <header>Reset Password</header>
    <main>
      layout
    </main>
</template>

<script lang="ts">
</script>

<style lang="scss">
</style>
