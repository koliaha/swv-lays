<template>
    <header>Authorization RTL</header>
    <main>
      <forms-auth-credentials-form is-rtl="true" />
    </main>
</template>

<script lang="ts">
</script>

<style lang="scss">
</style>
