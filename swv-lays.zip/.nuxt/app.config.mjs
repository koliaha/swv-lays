
import { defuFn } from 'C:/Users/haqua/Documents/vue/swv-lays/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
