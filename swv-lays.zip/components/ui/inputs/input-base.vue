<template>
  input base
</template>

<script lang="ts">
</script>

<style lang="scss">
</style>
